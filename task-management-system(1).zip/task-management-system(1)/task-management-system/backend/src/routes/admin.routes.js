const express = require('express');
const {
  getUsers,
  getUserDetails,
  updateUserStatus,
  deleteUser,
  getDashboardStats,
  getAllTasks,
  getActivityLogs
} = require('../controllers/admin.controller');
const { authenticate, isAdmin, isSuperAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();

// All routes require authentication and admin privileges
router.use(authenticate);
router.use(isAdmin);

// Dashboard & Stats
router.get('/stats', getDashboardStats);
router.get('/logs', getActivityLogs);

// User Management
router.get('/users', getUsers);
router.get('/users/:id', getUserDetails);
router.put('/users/:id/status', updateUserStatus);
router.delete('/users/:id', isSuperAdmin, deleteUser); // Only super admin can delete users

// Task Management
router.get('/tasks', getAllTasks);

module.exports = router;
