const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create admin user
  const adminPasswordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@123456', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: process.env.ADMIN_EMAIL || 'admin@taskmanagement.com' },
    update: {},
    create: {
      email: process.env.ADMIN_EMAIL || 'admin@taskmanagement.com',
      passwordHash: adminPasswordHash,
      name: 'System Admin',
      role: 'SUPER_ADMIN',
      isVerified: true,
      isActive: true
    }
  });

  console.log('✅ Admin user created:', admin.email);

  // Create demo user
  const demoPasswordHash = await bcrypt.hash('Demo@123456', 10);
  
  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: {
      email: 'demo@example.com',
      passwordHash: demoPasswordHash,
      name: 'Demo User',
      role: 'USER',
      isVerified: true,
      isActive: true
    }
  });

  console.log('✅ Demo user created:', demoUser.email);

  // Create sample tasks for demo user
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const nextWeek = new Date(today);
  nextWeek.setDate(nextWeek.getDate() + 7);

  const sampleTasks = [
    {
      userId: demoUser.id,
      title: 'Complete project proposal',
      description: 'Write and submit the Q1 project proposal',
      dueDate: tomorrow,
      priority: 'HIGH',
      status: 'IN_PROGRESS',
      category: 'Work'
    },
    {
      userId: demoUser.id,
      title: 'Team meeting',
      description: 'Weekly sync with the development team',
      dueDate: today,
      priority: 'MEDIUM',
      status: 'PENDING',
      category: 'Meetings'
    },
    {
      userId: demoUser.id,
      title: 'Review pull requests',
      description: 'Review pending PRs from team members',
      dueDate: today,
      priority: 'MEDIUM',
      status: 'PENDING',
      category: 'Development'
    },
    {
      userId: demoUser.id,
      title: 'Update documentation',
      description: 'Update API documentation with new endpoints',
      dueDate: nextWeek,
      priority: 'LOW',
      status: 'PENDING',
      category: 'Documentation'
    },
    {
      userId: demoUser.id,
      title: 'Deploy to staging',
      description: 'Deploy latest changes to staging environment',
      dueDate: tomorrow,
      priority: 'HIGH',
      status: 'COMPLETED',
      category: 'DevOps'
    }
  ];

  for (const taskData of sampleTasks) {
    await prisma.task.create({
      data: taskData
    });
  }

  console.log(`✅ Created ${sampleTasks.length} sample tasks`);

  console.log('🎉 Database seeding completed!');
  console.log('');
  console.log('Login credentials:');
  console.log('Admin: admin@taskmanagement.com / Admin@123456');
  console.log('Demo User: demo@example.com / Demo@123456');
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
