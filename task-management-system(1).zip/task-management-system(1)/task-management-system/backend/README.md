# Task Management System - Backend API

Node.js/Express backend API for the Task Management System.

## Features

- JWT-based authentication
- RESTful API design
- PostgreSQL database with Prisma ORM
- Role-based access control (User, Admin, Super Admin)
- Rate limiting and security middleware
- Input validation with express-validator
- Comprehensive error handling

## Tech Stack

- **Runtime**: Node.js 18+
- **Framework**: Express.js
- **Database**: PostgreSQL
- **ORM**: Prisma
- **Authentication**: JWT
- **Validation**: express-validator
- **Security**: Helmet, bcryptjs

## Getting Started

### Prerequisites

- Node.js 18 or higher
- PostgreSQL 14 or higher
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables:
```bash
cp .env.example .env
```

Edit `.env` with your database credentials and secrets.

3. Set up the database:
```bash
# Run migrations
npx prisma migrate dev

# Seed the database with sample data
npm run seed
```

4. Start the development server:
```bash
npm run dev
```

The server will run on `http://localhost:5000`

## Database Schema

### User Model
- `id` (UUID, Primary Key)
- `email` (String, Unique)
- `passwordHash` (String)
- `name` (String)
- `role` (Enum: USER, ADMIN, SUPER_ADMIN)
- `isVerified` (Boolean)
- `isActive` (Boolean)
- Timestamps

### Task Model
- `id` (UUID, Primary Key)
- `userId` (UUID, Foreign Key)
- `title` (String)
- `description` (Text)
- `dueDate` (DateTime)
- `priority` (Enum: LOW, MEDIUM, HIGH)
- `status` (Enum: PENDING, IN_PROGRESS, COMPLETED)
- `category` (String, Optional)
- Timestamps

### AdminLog Model
- `id` (UUID, Primary Key)
- `adminEmail` (String)
- `action` (String)
- `targetType` (String)
- `targetId` (String)
- `details` (Text)
- `ipAddress` (String)
- `createdAt` (DateTime)

## API Endpoints

### Authentication
```
POST   /api/auth/register    - Register new user
POST   /api/auth/login       - User login
GET    /api/auth/me          - Get current user (Protected)
POST   /api/auth/logout      - Logout user (Protected)
```

### Tasks
```
GET    /api/tasks            - Get all user tasks (Protected)
GET    /api/tasks/by-date    - Get tasks grouped by date (Protected)
GET    /api/tasks/:id        - Get single task (Protected)
POST   /api/tasks            - Create new task (Protected)
PUT    /api/tasks/:id        - Update task (Protected)
DELETE /api/tasks/:id        - Delete task (Protected)
```

### Admin
```
GET    /api/admin/stats      - Get dashboard statistics (Admin)
GET    /api/admin/users      - Get all users (Admin)
GET    /api/admin/users/:id  - Get user details (Admin)
PUT    /api/admin/users/:id/status - Update user status (Admin)
DELETE /api/admin/users/:id  - Delete user (Super Admin)
GET    /api/admin/tasks      - Get all tasks (Admin)
GET    /api/admin/logs       - Get activity logs (Admin)
```

## Scripts

```bash
npm start          # Start production server
npm run dev        # Start development server with nodemon
npm test           # Run tests
npm run migrate    # Run database migrations
npm run seed       # Seed database with sample data
npm run studio     # Open Prisma Studio
```

## Environment Variables

See `.env.example` for all required environment variables.

Key variables:
- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Secret for JWT signing
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment (development/production)

## Security Features

- Password hashing with bcrypt
- JWT token authentication
- Rate limiting on sensitive endpoints
- Helmet for security headers
- Input validation and sanitization
- CORS configuration
- SQL injection prevention (Prisma ORM)

## Default Credentials (After Seeding)

**Admin Account:**
- Email: admin@taskmanagement.com
- Password: Admin@123456

**Demo User:**
- Email: demo@example.com
- Password: Demo@123456

⚠️ **Change these credentials in production!**

## Error Handling

The API uses a centralized error handling middleware that returns consistent error responses:

```json
{
  "success": false,
  "message": "Error message",
  "error": "Detailed error (development only)"
}
```

## License

MIT
