'use client'

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Task Management System
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Organize your tasks efficiently with day-wise serial display
          </p>
          
          <div className="bg-white rounded-lg shadow-xl p-8 mb-8">
            <h2 className="text-2xl font-semibold mb-4">Welcome! 👋</h2>
            <p className="text-gray-600 mb-6">
              Your frontend is up and running. Connect to the backend API to get started.
            </p>
            
            <div className="grid md:grid-cols-2 gap-4">
              <a 
                href="/login" 
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
              >
                Login
              </a>
              <a 
                href="/register" 
                className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition"
              >
                Register
              </a>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-3xl mb-2">📅</div>
              <h3 className="font-semibold mb-2">Day-wise Display</h3>
              <p className="text-sm text-gray-600">Tasks organized by date serially</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-3xl mb-2">🔐</div>
              <h3 className="font-semibold mb-2">Secure Auth</h3>
              <p className="text-sm text-gray-600">JWT-based authentication</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-3xl mb-2">📊</div>
              <h3 className="font-semibold mb-2">Admin Panel</h3>
              <p className="text-sm text-gray-600">Complete system management</p>
            </div>
          </div>

          <div className="mt-8 text-sm text-gray-500">
            <p>API URL: {process.env.NEXT_PUBLIC_API_URL || 'Not configured'}</p>
            <p className="mt-2">Check QUICK_START.md for setup instructions</p>
          </div>
        </div>
      </div>
    </main>
  )
}
